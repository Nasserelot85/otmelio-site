#!/bin/sh
set -eu

if [ "$(id -u)" -ne 0 ]; then
    printf '%s\n' 'Run as root.' >&2
    exit 1
fi

SOURCE_DIR=${1:-.}
BRIDGE_SOURCE=$SOURCE_DIR/cam_n8n_read_only_bridge.py
LAUNCHER_SOURCE=$SOURCE_DIR/cam-n8n-readonly-run
UNIT_SOURCE=$SOURCE_DIR/cam-n8n-readonly@.service

for required in "$BRIDGE_SOURCE" "$LAUNCHER_SOURCE" "$UNIT_SOURCE"; do
    if [ ! -f "$required" ]; then
        printf 'Missing required file: %s\n' "$required" >&2
        exit 1
    fi
done

/usr/bin/python3 "$BRIDGE_SOURCE" --self-test >/dev/null
/usr/bin/python3 -m py_compile "$BRIDGE_SOURCE"
/usr/bin/bash -n "$LAUNCHER_SOURCE"

/usr/bin/install -d -o root -g root -m 0755 /opt/cam-n8n-readonly
/usr/bin/install -d -o root -g root -m 0755 /usr/local/libexec
/usr/bin/install -d -o root -g root -m 0700 /etc/credstore.encrypted
/usr/bin/install -d -o root -g root -m 0700 /var/lib/cam-n8n-readonly
/usr/bin/install -o root -g root -m 0755 "$BRIDGE_SOURCE" /opt/cam-n8n-readonly/cam_n8n_read_only_bridge.py
/usr/bin/install -o root -g root -m 0755 "$LAUNCHER_SOURCE" /usr/local/libexec/cam-n8n-readonly-run
/usr/bin/install -o root -g root -m 0644 "$UNIT_SOURCE" /etc/systemd/system/cam-n8n-readonly@.service

/usr/bin/systemd-analyze verify /etc/systemd/system/cam-n8n-readonly@.service
/usr/bin/systemctl daemon-reload

printf '%s\n' 'BRIDGE_FILES_DEPLOYED'
printf '%s\n' 'SECRET_NOT_CONFIGURED'
printf '%s\n' 'SERVICE_NOT_STARTED'
