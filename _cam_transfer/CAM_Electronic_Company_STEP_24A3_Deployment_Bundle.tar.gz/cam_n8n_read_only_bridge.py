#!/usr/bin/env python3
"""Minimum authenticated read-only bridge for the correct CAM n8n instance.

STEP 23 only. The bridge accepts an API key through an environment variable,
pins the exact HTTPS host, issues GET requests only, blocks redirects, limits
paths and query parameters, and redacts secret-like response fields.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import ssl
from typing import Any, Callable
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener, HTTPSHandler


VERSION = "1.0.0"
EXPECTED_ORIGIN = "https://n8n-cqqr.srv1932573.hstgr.cloud"
API_PREFIX = "/api/v1"
ALLOWED_RESOURCES = {
    "workflows": {"limit", "cursor", "active", "tags", "name", "projectId", "excludePinnedData"},
    "executions": {"limit", "cursor", "status", "workflowId", "projectId", "includeData"},
    "tags": {"limit", "cursor"},
    "projects": {"limit", "cursor"},
}
SECRET_KEY_PATTERN = re.compile(
    r"(?:password|secret|token|api[_-]?key|authorization|cookie|private[_-]?key|client[_-]?secret|access[_-]?token|refresh[_-]?token)",
    re.IGNORECASE,
)
MAX_RESPONSE_BYTES = 5_000_000


class BridgeError(ValueError):
    pass


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # type: ignore[no-untyped-def]
        raise BridgeError("REDIRECT_BLOCKED")


def _validate_origin(origin: str) -> str:
    parsed = urlparse(origin)
    if origin.rstrip("/") != EXPECTED_ORIGIN or parsed.scheme != "https" or parsed.hostname != "n8n-cqqr.srv1932573.hstgr.cloud":
        raise BridgeError("N8N_ORIGIN_NOT_AUTHORIZED")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise BridgeError("N8N_ORIGIN_MUST_NOT_CONTAIN_CREDENTIALS_OR_QUERY")
    return EXPECTED_ORIGIN


def _validate_request(resource: str, item_id: str | None, params: dict[str, Any] | None) -> tuple[str, dict[str, str]]:
    if resource not in ALLOWED_RESOURCES:
        raise BridgeError("RESOURCE_NOT_ALLOWED")
    if item_id is not None and not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", item_id):
        raise BridgeError("ITEM_ID_INVALID")
    clean: dict[str, str] = {}
    for key, value in (params or {}).items():
        if key not in ALLOWED_RESOURCES[resource]:
            raise BridgeError(f"QUERY_PARAMETER_NOT_ALLOWED:{key}")
        if value is None:
            continue
        if isinstance(value, bool):
            clean[key] = "true" if value else "false"
        elif isinstance(value, (str, int)) and len(str(value)) <= 512:
            clean[key] = str(value)
        else:
            raise BridgeError(f"QUERY_PARAMETER_INVALID:{key}")
    if resource == "executions":
        clean["includeData"] = "false"
    path = f"{API_PREFIX}/{resource}" + (f"/{item_id}" if item_id else "")
    return path, clean


def redact(value: Any) -> Any:
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            if SECRET_KEY_PATTERN.search(str(key)):
                result[key] = "[REDACTED]"
            elif key == "credentials" and isinstance(item, dict):
                result[key] = {
                    name: {k: v for k, v in ref.items() if k in {"id", "name", "type"}}
                    if isinstance(ref, dict) else "[REFERENCE_ONLY]"
                    for name, ref in item.items()
                }
            else:
                result[key] = redact(item)
        return result
    if isinstance(value, list):
        return [redact(item) for item in value]
    return value


def _network_get(url: str, api_key: str, timeout: int) -> Any:
    request = Request(url, method="GET", headers={"Accept": "application/json", "X-N8N-API-KEY": api_key, "User-Agent": "CAM-N8N-ReadOnly-Bridge/1.0"})
    opener = build_opener(_NoRedirect(), HTTPSHandler(context=ssl.create_default_context()))
    try:
        with opener.open(request, timeout=timeout) as response:
            if response.status != 200:
                raise BridgeError(f"UNEXPECTED_HTTP_STATUS:{response.status}")
            content_length = response.headers.get("Content-Length")
            if content_length and int(content_length) > MAX_RESPONSE_BYTES:
                raise BridgeError("RESPONSE_TOO_LARGE")
            raw = response.read(MAX_RESPONSE_BYTES + 1)
            if len(raw) > MAX_RESPONSE_BYTES:
                raise BridgeError("RESPONSE_TOO_LARGE")
            return json.loads(raw.decode("utf-8"))
    except HTTPError as exc:
        raise BridgeError(f"N8N_HTTP_ERROR:{exc.code}") from None
    except URLError:
        raise BridgeError("N8N_NETWORK_ERROR") from None
    except json.JSONDecodeError:
        raise BridgeError("N8N_RESPONSE_NOT_JSON") from None


def inspect(
    resource: str,
    *,
    item_id: str | None = None,
    params: dict[str, Any] | None = None,
    origin: str = EXPECTED_ORIGIN,
    api_key: str | None = None,
    transport: Callable[[str, str, int], Any] = _network_get,
    timeout: int = 15,
) -> dict[str, Any]:
    origin = _validate_origin(origin)
    path, clean_params = _validate_request(resource, item_id, params)
    key = api_key if api_key is not None else os.environ.get("CAM_N8N_READONLY_API_KEY")
    if not key or not isinstance(key, str) or len(key.strip()) < 12:
        raise BridgeError("READ_ONLY_API_KEY_UNAVAILABLE")
    url = origin + path + (("?" + urlencode(clean_params)) if clean_params else "")
    payload = transport(url, key, timeout)
    return {
        "BRIDGE_VERSION": VERSION,
        "MODE": "AUTHENTICATED_READ_ONLY",
        "ORIGIN": origin,
        "METHOD": "GET",
        "RESOURCE": resource,
        "ITEM_ID": item_id,
        "DATA": redact(payload),
        "WRITE_CAPABILITY": False,
        "SECRET_VALUES_RETURNED": False,
    }


def preflight() -> dict[str, Any]:
    key_present = bool(os.environ.get("CAM_N8N_READONLY_API_KEY"))
    return {
        "BRIDGE_VERSION": VERSION,
        "EXPECTED_ORIGIN": EXPECTED_ORIGIN,
        "ALLOWED_METHODS": ["GET"],
        "ALLOWED_RESOURCES": sorted(ALLOWED_RESOURCES),
        "API_KEY_ENVIRONMENT_REFERENCE": "CAM_N8N_READONLY_API_KEY",
        "API_KEY_PRESENT": key_present,
        "LIVE_INSPECTION_READY": key_present,
        "WRITE_CAPABILITY": False,
    }


def run_self_tests() -> dict[str, Any]:
    checks=[]
    def check(name: str, passed: bool) -> None: checks.append({"TEST":name,"PASS":bool(passed)})
    def rejected(name: str, fn: Callable[[], Any]) -> None:
        try: fn(); check(name,False)
        except BridgeError: check(name,True)
    captured={}
    def fake(url: str, key: str, timeout: int) -> Any:
        captured.update(url=url,key=key,timeout=timeout)
        return {"data":[{"id":"W1","name":"CAM Test","active":True,"apiKey":"do-not-return","credentials":{"google":{"id":"C1","name":"Sheets","type":"googleSheetsOAuth2Api","password":"hidden"}}}]}
    result=inspect("workflows",params={"limit":10,"active":True},api_key="test-key-123456",transport=fake)
    check("get_only",result["METHOD"]=="GET" and result["WRITE_CAPABILITY"] is False)
    check("correct_origin",captured["url"].startswith(EXPECTED_ORIGIN+API_PREFIX+"/workflows?"))
    check("api_key_header_only","test-key-123456" not in captured["url"])
    check("secret_redaction",result["DATA"]["data"][0]["apiKey"]=="[REDACTED]")
    ref=result["DATA"]["data"][0]["credentials"]["google"]
    check("credential_reference_only",set(ref)=={"id","name","type"} and "password" not in ref)
    execution=inspect("executions",params={"includeData":True,"limit":5},api_key="test-key-123456",transport=fake)
    check("execution_data_forced_off","includeData=false" in captured["url"] and execution["RESOURCE"]=="executions")
    rejected("wrong_host_blocked",lambda:inspect("workflows",origin="https://example.com",api_key="test-key-123456",transport=fake))
    rejected("http_blocked",lambda:inspect("workflows",origin=EXPECTED_ORIGIN.replace("https://","http://"),api_key="test-key-123456",transport=fake))
    rejected("unknown_resource_blocked",lambda:inspect("users",api_key="test-key-123456",transport=fake))
    rejected("write_style_resource_blocked",lambda:inspect("workflows/activate",api_key="test-key-123456",transport=fake))
    rejected("unknown_query_blocked",lambda:inspect("workflows",params={"delete":"true"},api_key="test-key-123456",transport=fake))
    rejected("invalid_id_blocked",lambda:inspect("workflows",item_id="../secret",api_key="test-key-123456",transport=fake))
    rejected("missing_key_blocked",lambda:inspect("workflows",api_key="",transport=fake))
    check("preflight_no_secret",preflight()["API_KEY_ENVIRONMENT_REFERENCE"]=="CAM_N8N_READONLY_API_KEY")
    passed=sum(1 for x in checks if x["PASS"])
    return {"TOTAL":len(checks),"PASSED":passed,"FAILED":len(checks)-passed,"RESULTS":checks}


def main() -> int:
    parser=argparse.ArgumentParser(description="CAM n8n authenticated read-only bridge")
    parser.add_argument("resource",nargs="?",choices=sorted(ALLOWED_RESOURCES))
    parser.add_argument("--id",dest="item_id")
    parser.add_argument("--params",default="{}",help="JSON object of allowlisted query parameters")
    parser.add_argument("--preflight",action="store_true")
    parser.add_argument("--self-test",action="store_true")
    args=parser.parse_args()
    if args.self_test:
        result=run_self_tests(); print(json.dumps(result,indent=2)); return 0 if result["FAILED"]==0 else 1
    if args.preflight:
        print(json.dumps(preflight(),indent=2)); return 0
    if not args.resource: parser.error("resource is required unless --preflight or --self-test is used")
    try:
        params=json.loads(args.params)
        if not isinstance(params,dict): raise BridgeError("PARAMS_MUST_BE_JSON_OBJECT")
        print(json.dumps(inspect(args.resource,item_id=args.item_id,params=params),indent=2,ensure_ascii=False)); return 0
    except (BridgeError,json.JSONDecodeError) as exc:
        print(json.dumps({"STATUS":"BLOCKED","ERROR":str(exc),"WRITE_CAPABILITY":False,"SECRET_VALUES_RETURNED":False})); return 2


if __name__=="__main__": raise SystemExit(main())
